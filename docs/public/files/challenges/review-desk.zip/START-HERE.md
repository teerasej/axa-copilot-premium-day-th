# Review Desk starter pack

## Your mission

A colleague needs a practical way to review Copilot-assisted material before sharing it. Adapt four checks into a useful review aid and demonstrate it on the supplied fictional draft.

Start by opening `Asteria_Review_Desk_Checklist.docx` in Word. Then choose your own route. Use at least two of Word, Excel and PowerPoint meaningfully and use Copilot at least once. This pack does not prescribe an app sequence. Your relevant morning Asteria outputs are also valid starting material.

## Files

- `Asteria_Review_Desk_Checklist.docx`: Four general review checks to adapt into your own review aid.
- `Asteria_Draft_for_Review.docx`: Fictional draft for review that deliberately mixes supported and unsupported statements.
- `Asteria_Grounded_Evidence_Brief.docx`: Prepared checked reference describing the pre-meeting position. Preserve its uncertainty and source locations.

## Result and next step

Level 1: A four-check review aid made easier to apply through Excel or PowerPoint, demonstrated on the supplied draft with evidence or gaps recorded.

Full mission, optional prompt ideas and Level 2: https://teerasej.github.io/axa-copilot-premium-day-th/th/exercises/challenges/review-desk

## Synthetic data boundary

All files describe fictional Asteria practice material, not AXA operational data. Save group copies. Do not add real customer, email or meeting data. Keep prepared sources separate from your own work. The evidence brief describes the pre-meeting position; the meeting recap records later confirmed decisions. Use the timeframe specified on the mission page.

Copilot features vary by account. Use an available Copilot experience and standard editing where needed. Read the transcript directly if included; do not attach the VTT file to Copilot. Finish at the instructor’s checking/rehearsal cue. Level 2 is optional.
