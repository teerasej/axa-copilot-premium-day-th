# Management Pitch starter pack

## Your mission

Leadership needs a recommendation it can question and evaluate. Develop a short pitch for one decision, using another app to strengthen the evidence or reasoning.

Start by opening `Asteria_Presentation_Template.pptx` in PowerPoint. Then choose your own route. Use at least two of Word, Excel and PowerPoint meaningfully and use Copilot at least once. This pack does not prescribe an app sequence. Your relevant morning Asteria outputs are also valid starting material.

## Files

- `Asteria_Presentation_Template.pptx`: Prepared three-slide starting point to adapt; not a result created by your group.
- `Asteria_Service_KPI_28days.xlsx`: Original 28-day values, dates, formulas and context notes for analysis and checking.
- `Asteria_Operational_Context.docx`: Business questions and evidence boundaries; recorded events do not prove causes.

## Result and next step

Level 1: A recommendation in no more than three slides, supported by meaningful evidence work in Excel or argument development in Word.

Full mission, optional prompt ideas and Level 2: https://teerasej.github.io/axa-copilot-premium-day-th/th/exercises/challenges/management-pitch

## Synthetic data boundary

All files describe fictional Asteria practice material, not AXA operational data. Save group copies. Do not add real customer, email or meeting data. Keep prepared sources separate from your own work. The evidence brief describes the pre-meeting position; the meeting recap records later confirmed decisions. Use the timeframe specified on the mission page.

Copilot features vary by account. Use an available Copilot experience and standard editing where needed. Read the transcript directly if included; do not attach the VTT file to Copilot. Finish at the instructor’s checking/rehearsal cue. Level 2 is optional.
