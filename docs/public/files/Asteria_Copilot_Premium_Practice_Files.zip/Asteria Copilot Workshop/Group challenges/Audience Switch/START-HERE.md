# Audience Switch starter pack

## Your mission

Leadership and the delivery team need different explanations of the same evidence. Choose one verified finding and make it useful to both audiences without changing its meaning.

Start by opening `Asteria_Grounded_Evidence_Brief.docx` in Word. Then choose your own route. Use at least two of Word, Excel and PowerPoint meaningfully and use Copilot at least once. This pack does not prescribe an app sequence. Your relevant morning Asteria outputs are also valid starting material.

## Files

- `Asteria_Grounded_Evidence_Brief.docx`: Prepared checked reference describing the pre-meeting position. Preserve its uncertainty and source locations.
- `Asteria_Service_KPI_28days.xlsx`: Original 28-day values, dates, formulas and context notes for analysis and checking.
- `Asteria_Operational_Context.docx`: Business questions and evidence boundaries; recorded events do not prove causes.

## Result and next step

Level 1: Two audience-specific explanations of one verified finding, with meaningful Word work and a contribution from Excel or PowerPoint.

Full mission, optional prompt ideas and Level 2: https://teerasej.github.io/axa-copilot-premium-day-th/th/exercises/challenges/audience-switch

## Synthetic data boundary

All files describe fictional Asteria practice material, not AXA operational data. Save group copies. Do not add real customer, email or meeting data. Keep prepared sources separate from your own work. The evidence brief describes the pre-meeting position; the meeting recap records later confirmed decisions. Use the timeframe specified on the mission page.

Copilot features vary by account. Use an available Copilot experience and standard editing where needed. Read the transcript directly if included; do not attach the VTT file to Copilot. Finish at the instructor’s checking/rehearsal cue. Level 2 is optional.
