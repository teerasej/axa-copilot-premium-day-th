# PowerPoint Makeover starter pack

## Your mission

A busy reader cannot see the main message in a crowded slide. Improve it while preserving the facts, and use another document app to strengthen your thinking or evidence.

Start by opening `Asteria_Crowded_Slide_Example.pptx` in PowerPoint. Then choose your own route. Use at least two of Word, Excel and PowerPoint meaningfully and use Copilot at least once. This pack does not prescribe an app sequence. Your relevant morning Asteria outputs are also valid starting material.

## Files

- `Asteria_Crowded_Slide_Example.pptx`: Self-contained crowded slide with fictional package counts; independent of the KPI workbook.

## Result and next step

Level 1: One clearer slide with before/after evidence and supporting message work in Word or numerical checking in Excel.

Full mission, optional prompt ideas and Level 2: https://teerasej.github.io/axa-copilot-premium-day-th/th/exercises/challenges/powerpoint-makeover

## Synthetic data boundary

All files describe fictional Asteria practice material, not AXA operational data. Save group copies. Do not add real customer, email or meeting data. Keep prepared sources separate from your own work. The evidence brief describes the pre-meeting position; the meeting recap records later confirmed decisions. Use the timeframe specified on the mission page.

Copilot features vary by account. Use an available Copilot experience and standard editing where needed. Read the transcript directly if included; do not attach the VTT file to Copilot. Finish at the instructor’s checking/rehearsal cue. Level 2 is optional.
