# Meeting to Momentum starter pack

## Your mission

A colleague missed the service recovery meeting. Build a handover that makes the confirmed work, dependencies and next decision easy to understand and follow.

Start by opening `Asteria_Teams_Meeting_Recap.docx` in Word. Then choose your own route. Use at least two of Word, Excel and PowerPoint meaningfully and use Copilot at least once. This pack does not prescribe an app sequence. Your relevant morning Asteria outputs are also valid starting material.

## Files

- `Asteria_Teams_Meeting_Recap.docx`: Word meeting recap containing confirmed actions and unresolved dependencies.
- `Asteria_Executive_Review_Transcript.vtt`: Authoritative transcript for optional direct reading. Do not attach VTT to Copilot.

## Result and next step

Level 1: A handover covering at least three confirmed actions, their owners, dates and dependencies, with useful supporting work in Excel or PowerPoint.

Full mission, optional prompt ideas and Level 2: https://teerasej.github.io/axa-copilot-premium-day-th/th/exercises/challenges/meeting-to-momentum

## Synthetic data boundary

All files describe fictional Asteria practice material, not AXA operational data. Save group copies. Do not add real customer, email or meeting data. Keep prepared sources separate from your own work. The evidence brief describes the pre-meeting position; the meeting recap records later confirmed decisions. Use the timeframe specified on the mission page.

Copilot features vary by account. Use an available Copilot experience and standard editing where needed. Read the transcript directly if included; do not attach the VTT file to Copilot. Finish at the instructor’s checking/rehearsal cue. Level 2 is optional.
